import { Raleway } from "next/font/google";

const raleway = Raleway({ 
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-raleway",
});

export const metadata = {
  title: "5C Leadership Blueprint | Awakening Destiny Global",
  description: "Developing Leaders. Creating Champions. From Design to Destiny.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body
        className={raleway.variable}
        style={{
          margin: 0,
          padding: 0,
          fontFamily: "var(--font-raleway), 'Segoe UI', sans-serif",
        }}
      >
        {children}
      </body>
    </html>
  );
}
