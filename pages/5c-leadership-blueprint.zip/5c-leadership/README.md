# 5C Leadership Blueprint
**Awakening Destiny Global** — Developing Leaders. Creating Champions.

## Deploy to Vercel (3 steps)

### Step 1: Push to GitHub
1. Create a new repository on GitHub (github.com/new)
2. Name it `5c-leadership-blueprint` (or whatever you want)
3. Leave it **public** or **private** — either works
4. **Don't** add a README (we already have one)
5. Click "Create repository"
6. Open a terminal in this project folder and run:

```bash
git init
git add .
git commit -m "Initial 5C Leadership Blueprint"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/5c-leadership-blueprint.git
git push -u origin main
```

### Step 2: Connect to Vercel
1. Go to [vercel.com/new](https://vercel.com/new)
2. Click "Import Git Repository"
3. Select the repo you just pushed
4. Vercel auto-detects Next.js — leave all settings as default
5. Click "Deploy"
6. Wait ~60 seconds

### Step 3: Done
Your site is live at `https://5c-leadership-blueprint.vercel.app` (or whatever Vercel assigns).

Every future `git push` to `main` auto-deploys.

## Local Development

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## What's Built
- Course Introduction (8 sections with AI summary)
- Dashboard (progress, scores, roadmap)
- Module 1: Calling (13 sections — full teaching + diagnostics + commitments + AI summary)

## Next Steps
- Module 2: Connection
- Module 3: Competency  
- Module 4: Capacity
- Module 5: Convergence
- Supabase auth + database
- Claude API integration for real AI summaries
- DOCX export
- Conclusion / Testimony / Certificate
